<?php
class Random{
    public function random(){
        $model = $this->load->model('SlagalicaModel');
    }
}

?>